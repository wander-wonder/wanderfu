/**
 * Created by 10436 on 2019/7/14.
 */

$(function(){
	var i=0;
	var clone=$(".slide_photo .img li").first().clone();
	$(".slide_photo .img").append(clone);
	var size=$(".slide_photo .img li").size();
	for(var j=0;j<size-1;j++){
		$(".slide_photo .num").append("<li></li>");
	}
	$(".slide_photo .num li").first().addClass("on");


	/*鼠标划入圆点*/
	$(".slide_photo .num li").hover(function(){
		var index=$(this).index();
		i=index;
		$(".slide_photo .img").stop().animate({left:-index*1200},500)
		$(this).addClass("on").siblings().removeClass("on")
	})


	/*自动轮播*/
	var t=setInterval(function(){
		i++;
		move()
	},2000)

	/*对banner定时器的操作*/
	$(".slide_photo").hover(function(){
		clearInterval(t);
	},function(){
		t=setInterval(function(){
			i++;
			move()
		},2000)
	})

	/*向左的按钮*/
	$(".slide_photo .btn_l").click(function(){
		i++
		move();
	})

	/*向右的按钮*/
	$(".slide_photo .btn_r").click(function(){
		i--
		move();
	})

	function move(){

		if(i==size){
			$(".slide_photo  .img").css({left:0})      //CSS拉动是瞬间的，不会有效果
			i=1;
		}

		if(i==-1){
			$(".slide_photo .img").css({left:-(size-1)*1200})
			i=size-2;
		}

		$(".slide_photo .img").stop().animate({left:-i*1200},500)    //animate的拉动是缓慢的

		if(i==size-1){
			$(".slide_photo .num li").eq(0).addClass("on").siblings().removeClass("on")
		}else{
			$(".slide_photo .num li").eq(i).addClass("on").siblings().removeClass("on")
		}

	}
})
