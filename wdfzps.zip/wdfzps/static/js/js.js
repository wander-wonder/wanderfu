
    function dr(){
       var username=document.getElementById("username");
       var pass=document.getElementById("password");
       if(username.value=="")
       {
          alert("用户名不能为空");
          username.focus();
           return;
       }
       if(pass.value=="")
       {
           alert("密码不能为空");
           return;
       }
       return true;
       }
     function zr(){
       var username=document.getElementById("username");
       var pass=document.getElementById("password");
       var ver=document.getElementById("verification");
       var picture=document.getElementById("pictureCode1");
       if(username.value=="")
       {
          alert("号码不能为空");
          username.focus();
           return;
       }
       if(username.value.length!=11)
       {
          alert("号码格式错误");
          username.focus();
           return;
       }
       (picture.value=="")
       {
           alert("请输入图中的验证码");
           return;
       }
       if(ver.value=="")
       {
           alert("请输入验证码");
           return;
       }
       if(pass.value=="")
       {
           alert("密码不能为空");
           return;
       }
       response.sendRedirect("");
       return true;
       }
