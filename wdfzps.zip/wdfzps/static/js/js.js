
    function dr(){
       var username=document.getElementById("username");
       var pass=document.getElementById("password");
       if(username.value=="")
       {
          alert("用户名不能为空");
          username.focus();
           return;
       }
       if(pass.value=="")
       {
           alert("密码不能为空");
           return;
       }
       return true;
       }
     function zr(){
       var username=document.getElementById("phone");
       var pass=document.getElementById("password");
       var pass2=document.getElementById("password2");
       /*var ver=document.getElementById("verification");
       var picture=document.getElementById("pictureCode1");*/
       if(username.value=="")
       {
          alert("用户名不能为空");
          username.focus();
           return;
       }
       if(username.value.length!=11)
       {
          alert("号码格式错误");
          username.focus();
           return;
       }
       /*
       if(picture.value=="")
       {
           alert("请输入图中的验证码");
           return;
       }
       if(ver.value=="")
       {
           alert("请输入验证码");
           return;

       }
 */
       if(pass.value=="")
       {
           alert("密码不能为空");
           return false;
       }
       if(pass.value!=pass2.value)
       {
           alert("两次输入密码不同");
           pass.focus();
           return ;
       }
       if(pass.value.length>12|| pass.value.length < 6)
       {
           alert("密码请输入6-12位字符");
           pass.focus();
           return ;
       }
       return true;
       }
