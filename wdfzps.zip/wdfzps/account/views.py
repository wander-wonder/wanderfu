from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse

from .forms import RegistrationForm, UserProfileForm

# Create your views here.

def index(request):

    return render(request, "account/index.html")



def register(request):
    if request.method == "POST":
        user_form = RegistrationForm(request.POST)
        userprofile_form = UserProfileForm(request.POST)
        if user_form.is_valid():
            new_user = user_form.save(commit=False)
            new_user.set_password(user_form.cleaned_data['password'])
            new_user.save()
            new_profile = userprofile_form.save(commit=False)
            new_profile.user = new_user
            new_profile.save()
            return HttpResponse("successfully")
        else:
            return HttpResponse("sorry, you can not register.")
    else:
        user_form = RegistrationForm()
        userprofile_form = UserProfileForm()
        return render(request, "account/注册.html", {"form" : user_form, "profile" : userprofile_form})