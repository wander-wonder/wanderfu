from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from .forms import RegistrationForm, UserProfileForm, UserForm, UserInfoForm, UserAddForm, TemplateAddForm
from .models import UserProfile, UserInfo, User, TemplateImg

def show_template(request):
    return render(request, 'account/show_template.html')

def user_add_img(request):
    if request.method == "POST":
        af = UserAddForm(request.POST, request.FILES)
        if af.is_valid():
            name = af.cleaned_data['name']
            headimg = af.cleaned_data['headimg']
            style = af.clened_data['style']
            img = TemplateImg(name=name, headimg=headimg, style=style)
            img.save()
            return render(request, 'account/show_template.html',context={"img":img})
    else:
        af = TemplateAddForm()
        return render(request, 'account/add_template.html',context={"af":af})

def template_add_img(request):
    if request.method == "POST":
        af = TemplateAddForm(request.POST, request.FILES)
        if af.is_valid():
            name = af.cleaned_data['name']
            headimg = af.cleaned_data['headimg']
            img = TemplateImg(name=name, headimg=headimg)
            img.save()
            return render(request, 'account/show_template.html',context={"img":img})
    else:
        af = TemplateAddForm()
        return render(request, 'account/add_template.html',context={"af":af})


def index(request):

    return render(request, "account/index.html")



def register(request):
    if request.method == "POST":
        user_form = RegistrationForm(request.POST)
        userprofile_form = UserProfileForm(request.POST)

        count=User.objects.filter(username=request.POST.get("username")).count()
        if count != 0:
            return render(request, "account/注册.html", {"count":count,"form" : user_form, "profile" : userprofile_form})


        if user_form.is_valid()*userprofile_form.is_valid():
            new_user = user_form.save(commit=False)
            new_user.set_password(user_form.cleaned_data['password'])
            new_user.save()
            new_profile = userprofile_form.save(commit=False)
            new_profile.user = new_user
            new_profile.save()
            return render(request, "account/登录.html")
            return HttpResponse("successfully")
        else:

            #这里只是返回了他自己，有待改进, 前面count已解决
            return render(request, "account/注册.html", {"form" : user_form, "profile" : userprofile_form})
    else:
        user_form = RegistrationForm()
        userprofile_form = UserProfileForm()
        return render(request, "account/注册.html", {"form" : user_form, "profile" : userprofile_form})

@login_required()
def myself(request):
    userprofile = UserProfile.objects.get(user=request.user) if hasattr(request.user, 'userprofile') else UserProfile.objects.create(user=request.user)
    userinfo = UserInfo.objects.get(user=request.user) if hasattr(request.user, 'userinfo') else UserInfo.objects.create(user=request.user)
    return render(request, "account/myself.html", {"user":request.user, "userinfo":userinfo, "userprofile":userprofile})

@login_required()#login_url='/account/login/'
def myself_edit(request):
    userprofile = UserProfile.objects.get(user=request.user) if hasattr(request.user, 'userprofile') else UserProfile.objects.create(user=request.user)
    userinfo = UserInfo.objects.get(user=request.user) if hasattr(request.user, 'userinfo') else UserInfo.objects.create(user=request.user)
    if request.method == "POST":
        user_form = UserForm(request.POST)
        userprofile_form = UserProfileForm(request.POST)
        userinfo_form = UserInfoForm(request.POST)
        if user_form.is_valid() * userprofile_form.is_valid() * userinfo_form.is_valid():
            user_cd = user_form.cleaned_data
            userprofile_cd = userprofile_form.cleaned_data
            userinfo_cd = userinfo_form.cleaned_data
            request.user.email = user_cd['email']
            userprofile.birth = userprofile_cd['birth']
            userprofile.phone = userprofile_cd['phone']
            userinfo.company = userinfo_cd['company']
            userinfo.profession = userinfo_cd['profession']
            userinfo.address = userinfo_cd['address']
            request.user.save()
            userprofile.save()
            userinfo.save()
        return HttpResponseRedirect('/my-information/')
    else:
        user_form = UserForm(instance=request.user)
        userprofile_form = UserProfileForm(initial={"birth":userprofile.birth, "phone":userprofile.phone})
        userinfo_form = UserInfoForm(initial={"school":userinfo.school, "company":userinfo.company, "profession":userinfo.profession, "address":userinfo.address})
        return render(request, "account/myself_edit.html", {"user_form":user_form, "userprofile_form":userprofile_form, "userinfo_form":userinfo_form})



@login_required(login_url='/account/login/')
def my_image(request):
    if request.method == 'POST':
        img = request.POST['img']
        userinfo = UserInfo.objects.get(user=request.user.id)
        userinfo.photo = img
        userinfo.save()
        return HttpResponse("1")
    else:
        return render(request, 'account/imagecrop.html',)