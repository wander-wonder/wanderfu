from django.db import models
from django.contrib.auth.models import  User



class TemplateImg(models.Model):
    name = models.CharField(max_length=50)
    headimg = models.FileField(upload_to='hai_imgs',default='')

    def __str__(self):
        return self.name

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, unique=True)
    birth = models.DateField(blank=True, null=True)
    phone = models.CharField(max_length=20, null=True)

    def __str__(self):
        return 'user {}'.format(self.user.username)

class UserInfo(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, unique=True)
    school = models.CharField(max_length=100, blank=True)
    company = models.CharField(max_length=100, blank=True)
    profession = models.CharField(max_length=100, blank=True)
    address = models.CharField(max_length=100, blank=True)
    photo = models.ImageField(blank=True)

    def __str__(self):
        return "user:{}".format(self.user.username)


class UserImg(models.Model):
    img_user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, default='')
    name = models.CharField(max_length=50)
    headimg = models.FileField(upload_to='user_imgs',default='')
    style =models.CharField(max_length=50, null=True)

    def __str__(self):
        return self.name
