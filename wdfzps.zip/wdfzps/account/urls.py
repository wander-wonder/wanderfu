from django.urls import path
from . import views

#用内置方法实现登录和退出
from django.contrib.auth import views as auth_views

app_name = 'account'

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', auth_views.LoginView.as_view(template_name='account/登录.html'), name='user_login'),
    path('logout/', auth_views.LogoutView.as_view(), name='user_logout'),
    path('register/', views.register, name='user_register'),
    path('my-information/', views.myself, name='user_info'),
    path('edit-my-information/', views.myself_edit, name='edit_my_information'),
    path('add_template/', views.template_add_img, name='upload_template_img'),
    path('show_template/', views.show_template, name='show_template'),

]